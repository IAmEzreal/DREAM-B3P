import subprocess
import os
from utils.amino_acid import write_fasta
from pathlib import Path

def get_local_blast_results(data_dir, db_path, seqs):
    query_path = os.path.join(data_dir, 'blast_query.fasta')
    write_fasta(seqs, query_path)

    blastp = subprocess.Popen(
        ['C:/Program Files/NCBI/blast-2.16.0+/bin/blastp', '-db', str(db_path), '-max_target_seqs', '1', '-outfmt', '10', '-matrix', 'BLOSUM45',
         '-task', 'blastp-short', '-query', str(query_path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )

    results, err = blastp.communicate()
    # 打印错误信息
    # if err.decode():
    #     print("Error during BLAST execution:")
    #     print(err.decode())
    #     return None

    # 打印 BLAST 的结果
    # print("BLAST Results:")
    # print(f"results type: {type(results)}")
    # print(f"results.decode() type: {type(results.decode())}")
    # print(f"results.decode(): \n {results.decode()}")

    if not results.decode():
        print("Error: BLAST results are empty.")
        return None
    else:
        # print(f"BLAST Results: {parse_blast_results(results.decode(), seqs)}")
        return parse_blast_results(results.decode(), seqs)


def parse_blast_results(results, seqs):
    parsed = {}

    # 如果results为空或格式不正确
    if not results:
        print("Error: BLAST results are empty.")
        return None

    for line in results.split(os.linesep):
        line = line.strip()
        parts = line.split(',')
        if len(parts) != 12:
            continue
        # parsed[seqs[int(parts[0])]] = float(parts[-1])

        # 确保seqs[int(parts[0])]是有效的
        try:
            seq_index = int(parts[0])
            if seq_index < len(seqs):
                parsed[seqs[seq_index]] = float(parts[-1])
            else:
                print(f"Invalid index {seq_index} for seqs.")
        except Exception as e:
            print(f"Error processing line {line}: {e}")

    # 如果没有有效数据返回 None
    if not parsed:
        print("Error: No valid data parsed.")
        return None

    return parsed

if __name__ == '__main__':
    seqs = ['VLGGGSALLRSIPA', 'FCIGRL', 'CHAIYPRH']
    base_dir = Path(__file__).resolve().parent.parent
    data_path = base_dir / 'predictor/db'
    pos_db = data_path / 'pos'
    neg_db = data_path / 'neg'
    pos = get_local_blast_results(data_path, pos_db, seqs)
    print('blast pos\n {0}'.format(pos))
    neg = get_local_blast_results(data_path, neg_db, seqs)
    print('blast neg\n {0}'.format(neg))

